//
//  ToDo+CoreDataClass.swift
//  ToDoListApp
//
//  Created by syed fazal abbas on 17/05/23.
//
//

import Foundation
import CoreData

@objc(ToDo)
public class ToDo: NSManagedObject {

}
