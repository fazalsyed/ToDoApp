//
//  ToDo+CoreDataProperties.swift
//  ToDoListApp
//
//  Created by syed fazal abbas on 17/05/23.
//
//

import Foundation
import CoreData


extension ToDo {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ToDo> {
        return NSFetchRequest<ToDo>(entityName: "ToDo")
    }

    @NSManaged public var title: String?
    @NSManaged public var detail: String?

}

extension ToDo : Identifiable {

}
