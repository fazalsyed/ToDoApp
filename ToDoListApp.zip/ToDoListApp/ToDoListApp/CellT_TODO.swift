//
//  CellT_TODO.swift
//  ToDoListApp
//
//  Created by syed fazal abbas on 17/05/23.
//

import UIKit

class CellT_TODO: UITableViewCell {

    @IBOutlet var view: UIView!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblDetail: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
