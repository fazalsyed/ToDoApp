//
//  DataBaseHelper.swift
//  ToDoListApp
//
//  Created by syed fazal abbas on 17/05/23.
//

import Foundation
import CoreData
import UIKit

class DataBaseHelper{
    static let shareInstance = DataBaseHelper()
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func saveData(todoDodict : [String:String]){
        let data = NSEntityDescription.insertNewObject(forEntityName: "ToDo", into: context!) as? ToDo
        data!.title = todoDodict["Title"]
        data!.detail = todoDodict["Detail"]
        do{
            try context?.save()
        }
        catch{
            print("Data Not Saved")
        }
    }
    
    func fetchData() -> [ToDo]{
        var todo = [ToDo]()
        let fetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "ToDo")
        do{
            todo = try (context?.fetch(fetchRequest) as? [ToDo])!
        }
        catch{
            print("Data Not Fetched")
        }
        return todo
    }
    
    func deleteData(index: Int) -> [ToDo]{
        var todo = fetchData()
        context?.delete(todo[index])
        todo.remove(at: index)
        do{
            try context?.save()
        }
        catch{
            print("Data Not Deleted")
        }
        return todo
    }
    
    func UpdateData(todoDict : [String:String],index : Int){
        var data = fetchData()
        data[index].title = todoDict["Title"]
        data[index].detail = todoDict["Detail"]
        do{
            try context?.save()
        }
        catch{
            print("Data Not Saved")
        }
    }
}
