//
//  SaveDataVC.swift
//  ToDoListApp
//
//  Created by syed fazal abbas on 17/05/23.
//

import UIKit

class SaveDataVC: UIViewController {

    @IBOutlet var txtTittle: UITextField!
    @IBOutlet var txtDetail: UITextView!
    @IBOutlet var DetailView: UIView!
    var todoDetail : ToDo?
    @IBOutlet var btnSave: UIButton!
    var isUpdate = false
    var indexRow = Int()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        txtTittle.text = todoDetail?.title
        txtDetail.text = todoDetail?.detail
    }
    override func viewWillAppear(_ animated: Bool) {
       if isUpdate {
           btnSave.setTitle("Update", for: .normal)
        }
        else{
            btnSave.setTitle("Save", for: .normal)
        }
    }
    
    func setupUI(){
        DetailView.layer.borderColor = UIColor.gray.cgColor
        DetailView.layer.borderWidth = 1
        DetailView.layer.cornerRadius = 10
        DetailView.layer.masksToBounds = true
        DetailView.clipsToBounds = false
    }
    
    @IBAction func btnTappedSave(_ sender: UIButton) {
        saveData()
    }
    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as? ViewController
         self.navigationController?.popViewController(animated: true)
     }
    }
extension SaveDataVC{
    func saveData(){
        guard let Title =  txtTittle.text else {return}
        guard let Detail = txtDetail.text else {return}
        
        let todoDict = ["Title" : Title,
                        "Detail" : Detail
                         
         ]
        if isUpdate{
            DataBaseHelper.shareInstance.UpdateData(todoDict: todoDict, index: indexRow)
            isUpdate = true
        }
        else{
            DataBaseHelper.shareInstance.saveData(todoDodict: todoDict)
        }
    
    }
}
