//
//  ViewController.swift
//  ToDoListApp
//
//  Created by syed fazal abbas on 17/05/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var btnPlus: UIButton!
    @IBOutlet var tableView: UITableView!
    var data = [ToDo]()
    var isUpdate = false
    var indexRow = Int()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "CellT_TODO", bundle: nil), forCellReuseIdentifier: "CellT_TODO")
        data = DataBaseHelper.shareInstance.fetchData()
    }
    @IBAction func btnTappedPlus(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SaveDataVC") as? SaveDataVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}
extension ViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_TODO") as? CellT_TODO
        cell?.view.layer.cornerRadius = 10
        cell?.view.clipsToBounds = true
        cell?.view.clipsToBounds = false
        cell?.view.layer.borderWidth = 1
        cell?.view.layer.borderColor = UIColor.black.cgColor
        cell?.lblTitle.text = data[indexPath.row].title
        cell?.lblDetail.text = data[indexPath.row].detail
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            data = DataBaseHelper.shareInstance.deleteData(index: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SaveDataVC") as? SaveDataVC
        vc?.todoDetail = data[indexPath.row]
        vc?.isUpdate = true
        vc?.indexRow = indexRow
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}
